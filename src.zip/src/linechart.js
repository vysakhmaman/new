import React, { Component } from 'react';
import LineChart from 'react-linechart';
import '../node_modules/react-linechart/dist/styles.css';
import Project from './component/Project';


 var style1={marginLeft:'280px'};
 var style2={marginBottom:'5px',marginLeft:'70px'};
 var style3={marginLeft:'-90px',transform:'rotate(-90deg)',float: 'left',marginTop:'-240px'};

 class Line extends Component {
    render() {
        const data = [
            {									
                color: "steelblue", 
                points: [{x: 27, y: 3}, {x: 35, y: 5}, {x: 67, y: 20}] 
            }
        ];
        return (
<Project/>,
            <div>
                <div className="Line" style={{marginLeft:'50px',marginTop:'30px'}}>
                    <h3 style={style2}>Age v/s Number Of Customers</h3>
                    <LineChart 
                    
                    axisLabels={{x: 'My x Axis', y: 'My y Axis'}}
                        width={600}
                        height={400}
                        data={data}
                    />
                    <text class="svg-line-chart-label" style={style3} >No. of Customers</text>
                    <text class="svg-line-chart-label"  style={style1}>AGE</text>
                    
                </div>				
            </div>
        );
    }
}
export default Line;
