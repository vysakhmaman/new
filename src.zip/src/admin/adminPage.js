import React, { Component } from 'react';
import Project from '../component/Project';


import '../index.css';



class Admin_Page extends Component{

  
  render() {
    return (
      <div className="Admin">
       <Project/>
       <admin/>
    
    </div>
    ); 
  }
}
export default Admin_Page;
