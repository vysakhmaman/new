 import React, { Component } from 'react';
import Background from '../image/car.jpg';

var sectionStyle = {
  width: "100%",
  height: "400px",
  backgroundImage: "url(" + { Background } + ")"
};
 
 var styles={color:'white',textAlign: 'right', marginTop: '3em'};
 
 class Front extends Component{
    render() {
      return ( 
 <section style={ sectionStyle }>
      </section>,
      <div >
      <h1 style={styles}>We Provide Better Loan Experience</h1>
      </div>
      
      );          
        }
}
  
  
 


   export default Front;
