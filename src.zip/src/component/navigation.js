import React, { Component } from 'react';

var styles1={color:'red'};



class Nav extends Component{
    render() {
      return (
        <div className="Nav" style={{width: '300px', height: '150px'}}>
        <h1 style={styles1}>gsfdfwhf</h1>
        <a style="{{backgroundColor: Red}}" ></a>

        
      </div>
      ); 
    }
  }
  export default Nav;
  