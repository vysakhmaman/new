import React, { Component } from 'react';
 
var styles={color:'white',textAlign: 'right', marginTop: '3em'};

class Front extends Component{
   render() {
     return ( 
     <div >
     <h1 style={styles}>We Provide Better Loan Experience</h1>
     </div>
     
     );          
       }
}
 
 



  export default Front;