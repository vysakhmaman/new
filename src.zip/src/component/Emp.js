import React, { Component } from 'react';
import Project from './Project';
import PieChart from './piechart';
import { withRouter } from 'react-router-dom';
import Line from '../linechart';
import Chart from './Chart';
import Exp from './Exp';
var style1={marginTop:'200px'};
var style2={marginTop:'-100px'};



class Emp extends Component{
  render() {
    return (

      <div className="Emp" style={{overflow:'hidden'}}>
	
       
    <Project/>

<Exp/>

      <div style={style1}>
       <Line/>
       </div>
     
       <div style={style2}>
         
       <PieChart/>
       </div>
<div><Chart/></div>

       
      <index/>
    </div>
    ); 
  }
}
export default withRouter(Emp);

