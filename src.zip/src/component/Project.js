import React, { Component } from 'react';


var styles={color:'white',top:'0',marginLeft:'20px'};
class Project extends Component{
    render() {
      return (
        <div className="Project">

       
<div style={{width:'100%',height:'90px',backgroundPositionY:'top',top:'0px',backgroundColor:'black',marginTop:'-20px',marginLeft:'-7px',marginRight:'10px'}}>


       <h1 style={styles}>INTELLI LOANS</h1>
        </div>
</div>
      ); 
    }
  }
  export default Project;
  
  
