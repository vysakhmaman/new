import React, { Component } from 'react';
import PieChart from 'react-simple-pie-chart';
import Business from './Business.png';
import moderate from './moderate.png';
import working from './working.png';





var style1={color:'black', textAlign:'center'};
var style2={marginLeft:'250px',marginTop:'-29px'};
var style3={marginLeft:'150px',marginTop:'-32px'};
var style4={marginLeft:'50px'};


class Piechart extends Component{
	

	render() {
      return (
        
        <div className="Piechart"style={{width:'25%',marginLeft:'850px',marginTop:'-450px'}}>
        <h3 style={style1}>Under Stand Your Customer</h3>
        <PieChart
       
  slices={[
    {
      label:'hai',
      color: '#e3411e',
      value: 10,

    },
    {label: "New",
      color: '#4c5eaf',
      value: 30,
    },
    {
      label: "New",
      color: '#e7a72e',
    value: 30,
    },
  ]}
  size={20}
 

/>

<div className="images" style={style4}>
<div className="image1" >
<img src={Business} alt="Logo" />
</div>
<div className="image2" style={style3}>
<img src={moderate} alt="Logo" />
</div>
<div className="image3" style={style2}>
<img src={working} alt="Logo" />
</div>
</div>
 
        
      </div>
      ); 
    }
  }
  export default Piechart; 
  
  

