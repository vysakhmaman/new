import React, { Component } from "react";
import './login.css';
import Project from './Project';
import Front from './front';
import { withRouter } from 'react-router-dom';


class Login extends Component{
      handleSubmit(){
            this.props.history.push({
              pathname:'/Emp',
            });
          }
            
     render(){
           
          
           return (
<div className="back" style={{backgroundSize:'100%'}}>

                <div className="border">
	
 			
			<Project/>
      			<Front/>

                      <div className="login">
                      <div className="head">
                      <h2 >Business Login</h2>
                      </div>
                      <br/>
                      <br/>
                      <form >
                      <input type="email" id="email" placeholder="Email"/>
                      <br/>
                      <br/>
                      <input type="password" id="password" placeholder="Password"/>
                      <br/>
                      <br/>
                      <button onClick={this.handleSubmit.bind(this)} id="login"  >Login</button>
                      </form>
              </div></div>
                  
                    </div>
                  
                
              );
        }
  }
  
  
  export default withRouter(Login);
