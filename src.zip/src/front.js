 import React, { Component } from 'react';
 
 
 class Front extends Component{
    render() {
      return ( 
      <div style={{paddingleft:'10em', paddingtop:'10em'}}>
      <h1>We Provide Better Loan Experience</h1>
      </div>
      
      );          
        }
}
  
  
 


   export default Front;
