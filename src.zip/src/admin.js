import React from 'react';
import ReactDOM from 'react-dom';
import adminPage from './Admin_Page';
import './index.css';

ReactDOM.render(
  <App />,
  document.getElementById('root1')
);
  
